package com.example.covid_1999_demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.w3c.dom.Text;

public class MainActivity<TextView2> extends AppCompatActivity {

    MqttHelper mqttHelper;

    TextView dataWater,dataGel;
    final String topic1 = "MqttTopic/water/";
    final String topic2 = "MqttTopic/gel/";
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataWater = (TextView) findViewById(R.id.dataWater);
        dataGel = (TextView) findViewById(R.id.dataGel);
        startMqtt();
    }

    private void startMqtt() {
        mqttHelper = new MqttHelper(getApplicationContext());
        mqttHelper.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {

            }

            @Override
            public void connectionLost(Throwable throwable) {

            }

            /*@Override
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                Log.w("Debug", mqttMessage.toString());

                dataWater.setText(mqttMessage.toString());
            }*/
            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                if (topic.equals(topic1)) {
                    dataWater.setText(new String(message.getPayload()));
                }
                if (topic.equals(topic2)) {
                    dataGel.setText(new String(message.getPayload()));
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

            }
        });
    }
}